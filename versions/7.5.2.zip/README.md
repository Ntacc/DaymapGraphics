# Daymap Graphics
Currently, Daymap's UI is composed of a white background, a white foreground and gainsboro text. Daymap Graphics is an extension that allows customisation of Daymap.
Daymap Graphics is based on my earlier [userscript](https://greasyfork.org/en/scripts/443619-daymap-graphics), which has ceased development in favour of the extension.

To download, download the latest version from the versions directory. Downloading old versions may cause them to automatically update to the newest version.
Once installed, click on the extension's icon in the toolbar for further instructions.
